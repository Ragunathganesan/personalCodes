package hooks;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImp extends BaseClass {
	
	@Before
	
	public void preCondition() {
	
		driver =new ChromeDriver();
		
		driver.get("http://eqaroloflow.co.za/wp/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	
	@After
	
	public void postCondition() {
		
		driver.quit();

	}
	
	
}

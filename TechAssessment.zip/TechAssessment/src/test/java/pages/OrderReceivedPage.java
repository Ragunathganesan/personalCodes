package pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OrderReceivedPage extends BaseClass{
	
	@When("Select Place your order")
	public void select_place_your_order() throws InterruptedException {
		
		Thread.sleep(3000);
		
	    driver.findElement(By.id("place_order")).click();
	}

	@Then("Print the order number")
	public void print_the_order_number() throws InterruptedException {
		
		Thread.sleep(3000);
		
		String text = driver.findElement(By.xpath("//li[contains(text(), 'Order number')]/strong")).getText();
		
		System.out.println(text);
		
		int actNumber = Integer.parseInt(text);
		
		Assert.assertTrue(actNumber>0, "Order Number Printed Successfully");
	}

}

package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;

public class CheckoutPage extends BaseClass{
	
	@Given("Select Check out")
	public void select_check_out() throws InterruptedException {
		Thread.sleep(3000);
	     driver.findElement(By.partialLinkText("Checkout")).click();
	     
	}

}

package pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyAccountPage extends BaseClass{

	@Given("Login using the My Account menu item with the username as {string} and password as {string}")
	public void login_using_the_my_account_menu_item_with_the_username_as_and_password_as(String username, String password) {
	   
		driver.findElement(By.xpath("//span[text()='My account']")).click();
		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
	}

}

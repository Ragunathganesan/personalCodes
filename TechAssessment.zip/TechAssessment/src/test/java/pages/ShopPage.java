package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;

public class ShopPage extends BaseClass{

	@Given("Go to Shop on the Menu bar")
	public void go_to_shop_on_the_menu_bar() {
	    driver.findElement(By.xpath("//span[text()='Shop']")).click();
	}

	@Given("Order a Californian pizza")
	public void order_a_californian_pizza() {
	  
		driver.findElement(By.xpath("//h2[contains(text(), 'Pizza ')]")).click();
		driver.findElement(By.xpath("//h2[text()='Californian Pizza']")).click();
	}
}

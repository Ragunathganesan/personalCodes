package apiSteps;

import java.util.List;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class APIImplementation {
	
	public Response response;
	
	@Given("Setup the EndPoint")
	public void setup_the_end_point() {
	   
		RestAssured.baseURI = "http://universities.hipolabs.com/search?country=South+Africa";
	}

	@When("Place the get request")
	public void place_the_get_request() {
	   
		response = RestAssured.get();
	}

	@Then("Print the state province")
	public void print_the_state_province() {
	    
		JsonPath jsonPath = response.jsonPath();
		
		List<String> nameList = jsonPath.getList("name");
		
		List<String> stateProvinceList = jsonPath.getList("state-province");
		
		for (int i = 0; i < nameList.size(); i++) {
			
			if (nameList.get(i).equals("University of Witwatersrand")) {
				
				System.out.println(stateProvinceList.get(i));
				Assert.assertTrue(stateProvinceList.get(i).equals("Gauteng Province"), "The state province value is displayed");
				
			}
			
		}
	}


}

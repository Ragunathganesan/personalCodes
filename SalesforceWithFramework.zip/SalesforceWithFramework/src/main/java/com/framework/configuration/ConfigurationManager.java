package com.framework.configuration;

import org.aeonbits.owner.Config;

@Config.Sources("classpath:config.properties")
public interface ConfigurationManager extends Config {
	
	
	@Key("url")
	
	String getUrl();
	
	@Key("username")
	
	String getUsername();
	
	@Key("password")
	
	String getPassword();
	
	@Key("fileds")
	
	String getfileds();
	
	@Key("lastname")
	
	String getLastname();
	
	@Key("createdIndividual")
	
	String getCreateIndividual();
	
	@Key("individualName")
	
	String getIndividualName();
	
	@Key("editFirstName")
	
	String getFirstName();
	
	@Key("editIndividual")
	
	String geteditIndividual();
	

}

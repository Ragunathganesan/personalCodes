package com.framework.configuration;

import org.aeonbits.owner.ConfigCache;

public class OwnerConfiguration {
	
	public static ConfigurationManager configuration() {
		
		ConfigurationManager create = ConfigCache.getOrCreate(ConfigurationManager.class);
		
		return create;

	}

}
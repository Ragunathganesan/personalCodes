package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.Salesforce_LoginPage;

public class TC_002_EditIndividual extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "TC_002_EditIndividual";
		testDescription ="Verify The Individual has edited";
		authors="Ragunath";
		category ="Smoke";
		excelFileName="Salesforce_EditIndividual";
	}

	@Test()
	public void editIndividual() {
		
		Salesforce_LoginPage editInd = new Salesforce_LoginPage();
		
		editInd.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickAppLauncher()
		.clickViewAll()
		.enterSearchFiled()
		.clickSearchContent()
		.searchIndividual()
		.clickSideActionButton()
		.clickEdit()
		.clickSalutation()
		.chooseSalutation()
		.enterEditFildFirstName()
		.clickSave()
		.verifyEditMessage();
	

	}
}

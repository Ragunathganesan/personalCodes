package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.Salesforce_LoginPage;

public class TC_001_CreateIndividual extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "TC_001_CreateIndividual";
		testDescription ="Verify The New Individual has created";
		authors="Ragunath";
		category ="Smoke";
		excelFileName="Salesforce";
	}
	
	@Test()
	public void createIndividual() {
		
		Salesforce_LoginPage createInd = new Salesforce_LoginPage();
		
		createInd.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickAppLauncher()
		.clickViewAll()
		.enterSearchFiled()
		.clickSearchContent()
		.clickIndividualDD()
		.clickNewIndividual()
		.enterLastName()
		.clickSave()
		.verifyIndividual();
		

	}

}

package com.pointofsale.pages;

import com.framework.configuration.OwnerConfiguration;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class Salesforce_HomePage extends ProjectSpecificMethods {
	
	public Salesforce_HomePage clickAppLauncher() {
		
		click(locateElement(Locators.XPATH, "//div[@class='slds-icon-waffle']"));
		reportStep("App Launcher Clicked Successfully", "Pass");
		return this;

	}
	
	public Salesforce_HomePage clickViewAll() {
		
		click(locateElement(Locators.XPATH, "//button[text()='View All']"));
		reportStep("View All Clicked Successfully", "Pass");
		return this;
		

	}
	
	public Salesforce_HomePage enterSearchFiled() {
		
		clearAndType(locateElement(Locators.XPATH, "//input[@placeholder='Search apps or items...']"), OwnerConfiguration.configuration().getfileds());
		reportStep("enterd successfully", "Pass");
		return this;
		
	}
	
	public Salesforce_IndividualPage clickSearchContent() {
		
		click(locateElement(Locators.XPATH, "//p[@class='slds-truncate']//mark"));
		reportStep("Moduel Clicked Successfully", "Pass");
		return new Salesforce_IndividualPage();

	}
	

}

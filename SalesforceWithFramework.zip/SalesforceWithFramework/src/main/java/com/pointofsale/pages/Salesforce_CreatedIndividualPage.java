package com.pointofsale.pages;

import com.framework.configuration.OwnerConfiguration;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class Salesforce_CreatedIndividualPage extends ProjectSpecificMethods{

	public Salesforce_CreatedIndividualPage verifyIndividual() {
		
		verifyPartialText(locateElement(Locators.XPATH, "//span[@class='toastMessage slds-text-heading--small forceActionsText']"), OwnerConfiguration.configuration().getCreateIndividual());
		reportStep(" created successfully", "pass");
		return this;
	}
	
	public Salesforce_CreatedIndividualPage verifyEditMessage() {
		
		verifyPartialText(locateElement(Locators.XPATH, "//span[contains(@class,'toastMessage')]"), OwnerConfiguration.configuration().geteditIndividual());
		reportStep(" edited successfully", "pass");
		return this;
	}
}

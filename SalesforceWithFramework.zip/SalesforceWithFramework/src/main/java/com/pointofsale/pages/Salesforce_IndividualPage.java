package com.pointofsale.pages;

import com.framework.configuration.OwnerConfiguration;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class Salesforce_IndividualPage extends ProjectSpecificMethods{
	
	public Salesforce_IndividualPage clickIndividualDD() {
		
		click(locateElement(Locators.XPATH, "(//a[@title='Individuals']/following::a)[1]"));
		reportStep("Individual Clicked Successfully", "pass");
		return this;

	}
	
	public Salesforce_IndividualPage clickNewIndividual() {
		
		clickUsingJs(locateElement(Locators.XPATH, "//span[text()='New Individual']"));
		reportStep("New Individual Clicked Successfully", "pass");
		return this;
	}
	
	public Salesforce_IndividualPage enterLastName() {
		
		clearAndType(locateElement(Locators.XPATH, "//input[contains(@class,'lastName compound')]"), OwnerConfiguration.configuration().getLastname());
		reportStep(" enterd successfully", "pass");
		return this;
	}
	
	public Salesforce_CreatedIndividualPage clickSave() {
		
		click(locateElement(Locators.XPATH, "(//span[text()='Save'])[2]"));
		reportStep("Save button clicked Successfully", "pass");
		return new Salesforce_CreatedIndividualPage();
	}
	
	public Salesforce_IndividualPage searchIndividual() {
		
		typeAndEnter(locateElement(Locators.XPATH, "//input[@name='Individual-search-input']"), OwnerConfiguration.configuration().getIndividualName());
		reportStep(" entered successfully", "pass");
		return this;

	}

	public Salesforce_IndividualPage clickSideActionButton() {
		
		pause(5000);
		
		clickUsingJs(locateElement(Locators.XPATH, "//a[contains(@class, 'keyboardMode--trigger')]"));
		reportStep("Action Button Clicked Successfully", "pass");
		return this;
	}
	
	public Salesforce_IndividualPage clickEdit() {
		
		clickUsingJs(locateElement(Locators.XPATH, "//a[@title='Edit']/div"));
		reportStep("Edit clicked Successfully", "pass");
		return this;

	}
	
	public Salesforce_IndividualPage clickSalutation() {
		
		click(locateElement(Locators.XPATH, "//a[@class='select']"));
		reportStep("Salutation Clicked Successfully", "pass");
		return this;
	}
	
	public Salesforce_IndividualPage chooseSalutation() {
		
		click(locateElement(Locators.XPATH, "//a[text()='Mr.']"));
		reportStep("Salutation Value Choosed Successfully", "pass");
		return this;

	}
	
	public Salesforce_IndividualPage enterEditFildFirstName() {
		
		clearAndType(locateElement(Locators.XPATH, "//input[contains(@class,'firstName')]"), OwnerConfiguration.configuration().getFirstName());
		reportStep( " entered successfully", "pass");
		return this;

	}
	
	
	
	
}

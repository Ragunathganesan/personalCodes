package com.pointofsale.pages;

import com.framework.configuration.OwnerConfiguration;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class Salesforce_LoginPage extends ProjectSpecificMethods {
	
	public Salesforce_LoginPage enterUsername() {
		
		clearAndType(locateElement(Locators.ID, "username"), OwnerConfiguration.configuration().getUsername());
		reportStep(" Username enterd Successfully", "pass");
		return this;
	}
	
	public Salesforce_LoginPage enterPassword() {
		
		clearAndType(locateElement(Locators.ID, "password"), OwnerConfiguration.configuration().getPassword());
		reportStep( " Password enterd Successfully", "pass");
		return this;

	}
	
	public Salesforce_HomePage clickLoginButton() {
		
		click(locateElement(Locators.ID, "Login"));
		reportStep("Login Clicked Successfully","pass");
		return new Salesforce_HomePage();

	}

}

package jsonLearning;

import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadDataFromJson {

	public static void main(String[] args) throws IOException, ParseException {
		
		// Create Obj for JSonParser Class
		
		JSONParser jsonParser = new JSONParser();
		
		// Create obj for FileReader Class
		
		FileReader reader = new FileReader("./jsonFiles/sample.json");
		
		Object parse = jsonParser.parse(reader);
		
		// Convert that Java object to JSON object
		
		JSONObject jsonObj	= (JSONObject)parse;
		
		// get the value from Json file
		
		String fname = (String)jsonObj.get("firstName");
		
		System.out.println(fname);
		
		
		String lName= (String) jsonObj.get("lastName");
		
		System.out.println(lName);
		
	JSONArray array = (JSONArray) jsonObj.get("address");
	
	for (int i = 0; i < array.size(); i++) {
		
		JSONObject obj = (JSONObject) array.get(i);
		
	String street = (String) obj.get("street");
	String city = (String) obj.get("city");
	String state = (String) obj.get("state");
	
	System.out.println("Street Name "+ street);
	System.out.println("City Name "+ city);
	System.out.println("State Name "+ state);
		
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		String fName = (String) jsonObj.get("firstName");
//		
//		System.out.println(fName);
//		
//		String lName = (String) jsonObj.get("lastName");
//		
//		System.out.println(lName);
//		
//		
//		JSONArray array = (JSONArray) jsonObj.get("address");
//		
//		for (int i = 0; i < array.size(); i++) {
//			
//			JSONObject address =(JSONObject)array.get(i);
//			
//			String street = (String) address.get("street");
//			String cityName = (String) address.get("city");
//			String state = (String) address.get("state");
//			
			
			
		//	System.out.println("Address From JSON File..."+i+"\nStreet Name " + street + "\nCity Name: " + cityName + "\nState Name: " + state);

			
		
		
			
		}
	}


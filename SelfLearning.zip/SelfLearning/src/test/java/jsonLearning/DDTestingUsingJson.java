package jsonLearning;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DDTestingUsingJson {
	
	public ChromeDriver driver;
	
	@BeforeMethod
	public void preCondition() {
		
		
		driver = new ChromeDriver();
		
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		

	}
	
	@AfterMethod
	public void postCondition() {
		
		driver.close();

	}
	
	@Test(dataProvider = "fetchData")
	public void loginLeaftaps(String data) {
		
		String[] sendData = data.split(",");
		
		driver.findElement(By.id("username")).sendKeys(sendData[0]);
		
		driver.findElement(By.id("password")).sendKeys(sendData[1]);
		
		driver.findElement(By.className("decorativeSubmit")).click();
		
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(sendData[2]);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Hari");
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("R");
		driver.findElement(By.name("submitButton")).click();
		
		
	}
	
	
	@DataProvider(name = "fetchData")
	public String[] sendData() throws IOException, ParseException {
		
		// Create Obj for JSonParser Class
		
				JSONParser jsonParser = new JSONParser();
				
				// Create obj for FileReader Class
				
				FileReader reader = new FileReader("./jsonFiles/leaftapsLogin.json");
				
				Object parse = jsonParser.parse(reader);
				
				// Convert that Java object to JSON object
				
				JSONObject jsonObj = (JSONObject)parse;
				
				JSONArray readDataInArray = (JSONArray) jsonObj.get("userLogin");
				
				String[] arr = new String[readDataInArray.size()];
				
				for (int i = 0; i < readDataInArray.size(); i++) {
					
					JSONObject userLog = (JSONObject) readDataInArray.get(i);
					
					String uName = (String) userLog.get("username");
					
					String pwd = (String) userLog.get("password");
					
					String companyName = (String) userLog.get("companyName");
					
					arr[i] = uName + "," + pwd + "," + companyName;
					
					
				}
				
				return arr;
	}
	

}

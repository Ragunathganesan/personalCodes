package iv_JavaProgram;

import java.util.HashMap;
import java.util.Map;

public class FrequencyOfVowels {
	
	public static void frqOfVowels() {
		
		
		String name = "Lavanya Sree Ragunath";
		

		String lowerCase = name.toLowerCase();
		
		Map<Character, Integer> vowelFrequency = new HashMap<Character, Integer>();
		
		vowelFrequency.put('a', 0);
		vowelFrequency.put('e', 0);
		vowelFrequency.put('i', 0);
		vowelFrequency.put('o', 0);
		vowelFrequency.put('u', 0);
		
		for (char ch: name.toCharArray()) {
			
			if (vowelFrequency.containsKey(ch)) {
				
				vowelFrequency.put(ch, vowelFrequency.get(ch)+1);
				
			}
			
		}
		
		System.out.println("Frequency of vowels in the string \"Lavanya Sree Ragunath\":");
        for (Map.Entry<Character, Integer> entry : vowelFrequency.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
     
        }
	}

	public static void main(String[] args) {
		
		frqOfVowels();
	}
}

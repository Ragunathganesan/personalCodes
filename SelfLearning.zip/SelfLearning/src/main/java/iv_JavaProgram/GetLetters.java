package iv_JavaProgram;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class GetLetters {
	
	public static void main(String[] args) {
		
		//Input: “Welcome to Capgemini”
		//Output: W C G M E I
		
		String name = "Welcome to Capgemini";
		
		char[] ch = name.toCharArray();
		
		Set<Character> set = new LinkedHashSet<Character>();
		

		for (int i = 0; i < ch.length; i++) {
			
			if (ch[i]=='W' || ch[i]=='c' || ch[i] == 'g' || ch[i]=='m' || ch[i]=='e' || ch[i]=='i') {
				
				char upperCase = Character.toUpperCase(ch[i]);
				
				for (int j = 0; j < ch.length; j++) {
					
					set.add(upperCase);
					
				}
				
//				if (!set.contains(upperCase)) {
//					
//					System.out.print(upperCase+" ");
//					
//					set.add(upperCase);
//					
//					
//					
//				}
//				
//				
				
				}
			
			
		}
		
		 System.out.println("\n" + set);
		
		//System.out.println();
		
		
	}

	
}

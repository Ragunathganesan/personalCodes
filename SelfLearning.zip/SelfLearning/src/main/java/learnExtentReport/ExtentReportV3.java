package learnExtentReport;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportV3 {

	public static void main(String[] args) throws IOException {
		
		// step 1 : Set up the path of the report folder
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		
		// step 2: Create object for ExtentReports
		ExtentReports extent = new ExtentReports();
		
		// step 3: attach the data with the physical file
		extent.attachReporter(reporter);
		
		
		//step 4: Create testcases and assign the details
		                                  // testcasename, testdescription
		ExtentTest test = extent.createTest("Login","Login with valid credentials");
		test.assignCategory("smoke");
		test.assignAuthor("Subraja");
		
		// step 5: Step level status
		test.pass("Username is entered successfully",MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/CM1.png").build());
		test.fail("Password is not entered successfully");
		test.fail("Login is not done");
		
		// Mandatory step
		extent.flush();
	
		System.out.println("Done");
		
		
		
	}
}

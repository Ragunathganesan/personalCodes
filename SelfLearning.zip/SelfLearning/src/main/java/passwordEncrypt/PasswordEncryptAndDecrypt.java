package passwordEncrypt;

import java.time.Duration;
import java.util.Base64;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class PasswordEncryptAndDecrypt {
	
	public static void main(String[] args) throws InterruptedException {
		
		String password = "crmsfa";
		
		byte[] encode = Base64.getEncoder().encode(password.getBytes());
		
		System.out.println(encode);
		
		String encodeValue = new String(encode);
		
		System.out.println(encodeValue);
		
		char[] charArray = password.toCharArray();
		
		int length = charArray.length;
		
		for (int i = 0; i < length; i=i+1) {
			
			//System.out.println(charArray[i]);
			
			if (i%2!=0) {
				
				char upperCase = Character.toUpperCase(charArray[i]);
				
				System.out.print(upperCase);
			}
			
			else {
				
				System.out.print(charArray[i]);
			}
			
		}
		
		
		byte[] decode = Base64.getDecoder().decode(encode);
		
		String string = new String(decode);
		
		System.out.println(string);
		
//		ChromeDriver driver = new ChromeDriver();
//		
//		driver.manage().window().maximize();
//		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		
//		driver.get("http://leaftaps.com/opentaps/control/main");
//		
//		driver.findElement(By.id("username")).sendKeys("DemoCSR");		
//		
//		driver.findElement(By.id("password")).sendKeys(string);
//		
//		driver.findElement(By.className("decorativeSubmit")).click();
		
	}

}

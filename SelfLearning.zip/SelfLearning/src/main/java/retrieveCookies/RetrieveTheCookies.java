package retrieveCookies;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.chrome.ChromeDriver;

public class RetrieveTheCookies {
	
	public static void main(String[] args) throws InterruptedException {
		
		// Initialize ChromeDriver

		ChromeDriver driver = new ChromeDriver();
		
		// Navigate to the login page

		driver.get("http://leaftaps.com/opentaps/control/main");
		
		 // Log in with valid credentials (manually or through automation)

		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		driver.findElement(By.className("decorativeSubmit")).click();
		
		// Retrieve cookies

		Set<Cookie> cookies = driver.manage().getCookies();
		
		// Output the cookies

		for (Cookie cookie : cookies) {
			
			System.out.println("Cookies Name: "+ cookie.getName());
			
			System.out.println("Cookies Value: "+ cookie.getValue());
			
		}
		
//		driver.close();
		
		// Add cookies to mimic an authenticated session
		
		

		
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		Thread.sleep(2000);
		
		for (Cookie cookie : cookies) {
			
				driver.manage().addCookie(cookie);
		}
		
		driver.navigate().refresh();
		
		
	}
	

}

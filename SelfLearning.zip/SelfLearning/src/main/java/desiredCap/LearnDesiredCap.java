package desiredCap;

import org.openqa.selenium.remote.DesiredCapabilities;

public class LearnDesiredCap {
	
	public static void main(String[] args) {
		
		DesiredCapabilities des = new DesiredCapabilities();
		
		System.out.println(des.getCapability("browsername"));
	}

}

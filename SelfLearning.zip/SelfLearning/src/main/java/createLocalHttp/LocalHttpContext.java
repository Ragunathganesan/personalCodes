package createLocalHttp;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

public class LocalHttpContext {

	public static void main(String[] args) {
		
		// Create a new cookie with the necessary authentication details
		Cookie authCookie = new Cookie("sessionID", "yourAuthToken");
		
		ChromeDriver driver = new ChromeDriver();

		// Add the cookie to the WebDriver instance
		driver.manage().addCookie(authCookie);

		// Navigate to the protected page
		driver.get("http://leaftaps.com/opentaps/control/main");

		// Construct the URL of the protected page
		String protectedPageUrl = "http://leaftaps.com/opentaps/control/main";

		// Navigate directly to the protected page
		driver.get(protectedPageUrl);
		
		FirefoxProfile profile = new FirefoxProfile();
		
		// Set up the profile with an active session or desired cookies
		
		FirefoxOptions option = new FirefoxOptions();
		
		option.setProfile(profile);
		
		//WebDriver driver1 = new FirefoxDriver();
		
		// Now, the WebDriver instance is using the profile with the logged-in session
		
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		

	}
}

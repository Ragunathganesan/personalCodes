package sslCertificate;

import java.time.Duration;

import org.testng.annotations.Test;

public class HandleSSLCertificate2 extends BaseClass {
	
	
	@Test
public void handleSSLCertFirefox() {
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://expired.badssl.com/");
		

	}
}

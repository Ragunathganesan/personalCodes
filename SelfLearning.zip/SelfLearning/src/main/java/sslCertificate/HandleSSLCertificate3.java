package sslCertificate;

import java.time.Duration;

import org.testng.annotations.Test;

public class HandleSSLCertificate3 extends BaseClass {
	

	@Test()
public void handleSSLCertEdge() {
	
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
	driver.get("https://expired.badssl.com/");
	

}

}

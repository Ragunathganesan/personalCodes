package sslCertificate;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseClass {
	
	public  ChromeDriver driver;
	
	
	@BeforeMethod
	public void preCondition() {
		
		ChromeOptions option = new ChromeOptions();
		
		option.setAcceptInsecureCerts(true);
		
		driver = new ChromeDriver(option);
		

	}
	
	@AfterMethod
	public void postCondition() {
		
	//	driver.close();

	}

}

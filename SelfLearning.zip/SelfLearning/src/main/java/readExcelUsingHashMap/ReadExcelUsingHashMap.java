package readExcelUsingHashMap;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelUsingHashMap {

	public static String[][] readExcel() throws IOException {
		
		XSSFWorkbook book = new XSSFWorkbook("./data/CreateLead.xlsx");
		
		XSSFSheet sheetAt = book.getSheetAt(0);
		
		int lastRowNum = sheetAt.getLastRowNum();
		
		int lastCellNum = sheetAt.getRow(0).getLastCellNum();
		
		Map<String, String> data = new HashMap<String, String>();
		
		String[][] getdata = new String[lastRowNum][lastCellNum];
		
		for (int i = 1; i <=lastRowNum; i++) {
			
			for (int j = 0; j <lastCellNum; j++) {
				
				String key = sheetAt.getRow(i).getCell(j).getStringCellValue();
				
				String value = sheetAt.getRow(i).getCell(j).getStringCellValue();
				
				data.put(key, value);
				
				String string = data.get(key);
				
				getdata[i-1][j]= string;
				
				System.out.println(string);
				
			//	String string1 = data.get(value);
				
				
			//	System.out.println(string1);
				
				
			}
		}
		
		book.close();
		return getdata;
		
	}
}

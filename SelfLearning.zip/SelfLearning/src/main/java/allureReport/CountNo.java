package allureReport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;

public class CountNo {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		//no of elements
		int n;
		n=sc.nextInt();
		int[] array = new int[n];
		for(int i=0; i<n;i++) {
			array[i]=sc.nextInt();
		}
		LinkedHashSet<Integer> set = new LinkedHashSet<Integer>();
		for(int i=0;i<n;i++)
		{
			set.add(array[i]);
		}
		//System.out.print(set);
		List<Integer> list = new ArrayList<Integer>(set);
		Collections.sort(list);
		int ans = list.size();
		System.err.println(ans-1);
		
	}

}


package snapShot;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

import com.assertthat.selenium_shutterbug.core.Capture;
import com.assertthat.selenium_shutterbug.core.Shutterbug;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class EntirePageScreenShot {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://www.amazon.in/");
		
		// Normal Screenshot
		
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		
		File desc = new File("./snap/imagename.png");
		
		FileUtils.copyFile(screenshotAs, desc);
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		// Screenshot for entire page using shutterbug
		
		Shutterbug.shootPage(driver, Capture.FULL, true).save("./snap/fullScreen");
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Mobiles");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("(//div[@class='s-suggestion-container']/div)[1]")).click();
		
		// Screenshot for entire page using Ashot
		
		Screenshot screenShot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		
		ImageIO.write(screenShot.getImage(), "PNG", new File("./snap/fullSnap.png"));
		
		driver.close();
	}
	
	
	

}

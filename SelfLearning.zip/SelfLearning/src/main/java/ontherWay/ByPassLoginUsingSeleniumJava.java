package ontherWay;


import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.cookie.BasicCookieStore;
import org.apache.hc.client5.http.cookie.CookieStore;
import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.apache.hc.client5.http.impl.async.HttpAsyncClients;
import org.apache.hc.client5.http.protocol.HttpClientContext;
import org.openqa.selenium.chrome.ChromeDriver;



public class ByPassLoginUsingSeleniumJava {
	
	public static void main(String[] args) {
		

	
	CloseableHttpAsyncClient httpClient = HttpAsyncClients.createDefault();
	
	// Create a local instance of cookie store
	
	CookieStore cookieStore = new BasicCookieStore();
	
	  // Create local HTTP context
	
	HttpClientContext localContext = HttpClientContext.create();
	
	// Bind custom cookie store to the local context
	
	localContext.setCookieStore(cookieStore);
	
	//HttpGet httpget = new HttpGet("http://leaftaps.com/opentaps/control/main");
	
//	System.out.println("Executing request "+ httpget.);
	
	httpClient.start();
	
	// Pass local context as a parameter
	
//	Future<HttpResponse> future = httpClient.execute(httpget, localContext, null);
	


}
}

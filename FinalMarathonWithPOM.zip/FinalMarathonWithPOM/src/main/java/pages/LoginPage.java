package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {
	
	public LoginPage enterUserName() {
		
		driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");

		return this;
	}
	
	public LoginPage enterPassword() {
	
		driver.findElement(By.id("password")).sendKeys("Testleaf@1234");
		
		return this;
	}

	public HomePage clickLoginButton() {
		
		driver.findElement(By.id("Login")).click();
		
		return new HomePage();

	}
}

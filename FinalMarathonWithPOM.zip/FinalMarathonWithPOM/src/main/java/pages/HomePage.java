package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod{
	
	public HomePage appLauncher() {
		
		driver.findElement(By.xpath("//button[contains(@class,'salesforceIdentityAppLauncherHeader')]")).click();
		
		return this;

	}
	
	public HomePage clickViewAll() {

		driver.findElement(By.xpath("//button[text()='View All']")).click();
		
		return this;

	}
	
	public HomePage enterSearchApp() {
		
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys("individuals");
		
		return this;

	}
	
	public IndividualsPage clickEnteredValue() {
		
		driver.findElement(By.xpath("//p[@class='slds-truncate']")).click();
		
		return new IndividualsPage();

	}

}

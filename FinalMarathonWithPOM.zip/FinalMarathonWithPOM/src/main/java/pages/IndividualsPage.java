package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;

public class IndividualsPage extends ProjectSpecificMethod {
	
	public IndividualsPage clickIndividualDropDownIcon() {
		
		driver.findElement(By.xpath("(//a[@title='Individuals']/following::a)[1]")).click();

		return this;
	}
	
	public IndividualsPage clickNewIndividual() {
		
		WebElement clk = driver.findElement(By.xpath("//span[text()='New Individual']"));
		
		driver.executeScript("arguments[0].click();", clk);
		
		return this;
	}
	
	public IndividualsPage enterLastName() {
		
		driver.findElement(By.xpath("//input[contains(@class,'lastName compound')]")).sendKeys("Ganesan");
		
		return this;

	}
	
	public IndividualsPage clickSaveButton() {
		
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		
		return this;
	}
	
	public void verifyIndividualCreated() {
		
		String message = driver
				.findElement(By.xpath("//span[@class='toastMessage slds-text-heading--small forceActionsText']"))
				.getText();
		
		System.out.println(message);

	}
	
	public IndividualsPage searchIndividuals() {
		
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys("Ganesan", Keys.ENTER);
		
		return this;

	}
	
	public IndividualsPage clickDropDow() {
		
		driver.findElement(By.xpath("(//div[contains(@class, 'forceVirtualAction')])[1]")).click();
		
		return this;

	}
	
	public void clickEdit() {
		
		driver.findElement(By.xpath("//div[text()='Edit']")).click();
		
		

	}

}

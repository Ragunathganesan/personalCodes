package week4;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class MaxFasion {

	public static void main(String[] args) throws IOException, InterruptedException {
		
//		Navigate to Max Fashion
		
		ChromeOptions option = new ChromeOptions();
		
		option.addArguments("--disable-notifications");
		
		ChromeDriver driver = new ChromeDriver(option);
		
		driver.get("https://www.maxfashion.in/in/en/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
				
//		Mouse over "Men" at the top menu.
		
		Actions act = new Actions(driver);
		
		WebElement men = driver.findElement(By.xpath("//div[@id='dept-men']/a"));
		
		act.moveToElement(men).perform();
		
//		Click on "Sports Shoes" under the "Footwear" category.
		
		WebElement sports = driver.findElement(By.xpath("(//a[text()='Sports Shoes'])[1]"));
		
		act.moveToElement(sports).click(sports).perform();
		
//		Sort by "New Arrivals" using the sort filter.
		
		driver.findElement(By.xpath("(//div[text()='SORT BY']//following::button)[1]")).click();
		
		driver.findElement(By.xpath("//div[text()='New Arrivals']")).click();
		
//		Print product availability (number of products listed).
		
		String productAvai = driver.findElement(By.xpath("(//p[contains(@class, 'MuiTypography-colorTextSecondary')])")).getText();
		
		System.out.println(productAvai);
		
		
//		Click on "Add" and Select a first color 
		
		driver.findElement(By.xpath("(//h6[text()='Color']/following::span)[2]")).click();
		
		driver.findElement(By.xpath("(//span[@class='MuiIconButton-label']/input)")).click();
		
//		Print the selected color.
		
		String choosedColor = driver.findElement(By.xpath("//span[@class='MuiChip-label']")).getText();
		
		System.out.println(choosedColor);
		
//		Print the name of all listed shoes.
		
		List<WebElement> shoesName = driver.findElements(By.xpath("//div[@dir='ltr']/a"));
		
		for (int i = 0; i < shoesName.size(); i++) {
			
			String names = shoesName.get(i).getText();
			
			System.out.println(names);
			
		}
		
		
		
//		Click on the first shoe to open its detailed page.
		
		Thread.sleep(5000);
		
		WebElement firstShoe = driver.findElement(By.xpath("(//div[@dir='ltr']/a)[1]"));
		
		driver.executeScript("arguments[0].click();", firstShoe);
		
//		Enter your pin code and check the delivery date.
		
		String parentWindow = driver.getWindowHandle();
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		List<String> newWindow = new ArrayList<String>(windowHandles);
		
		driver.switchTo().window(newWindow.get(1));
		
		driver.findElement(By.xpath("//input[@placeholder='Enter your Pincode']")).sendKeys("600125");
		
		driver.findElement(By.xpath("(//button[contains(@class, 'MuiButton-containedPrimary')])[2]")).click();
		
//		Print the delivery message displayed.
		
		Thread.sleep(3000);
		
		String deleveryInfo = driver.findElement(By.xpath("(//div[@id='pin-code-info']//following::div)[3]")).getText();
		
		System.out.println("Shoes Delivery info: "+ deleveryInfo);
		
//		Click "Add to Basket" for the selected shoe.
		
		WebElement addToBasket = driver.findElement(By.xpath("//div[@id='notify-quantity']//div/button"));
		
		driver.executeScript("arguments[0].click();", addToBasket);
		
//		Choose the second size option.
		
		driver.findElement(By.xpath("(//span[text()='Size Guide'])[2]/following::button[2]")).click();
		
//		Click "Add to Basket" again for the second size.
		
		driver.findElement(By.xpath("(//span[text()='ADD TO BASKET'])[2]")).click();
		
//		Print the total price in the basket.
		
		String totalPrice = driver.findElement(By.xpath("//span[text()='Checkout now']/preceding::div[1]")).getText();
		
		System.out.println(totalPrice);
				
//		Take a screenshot of the cart.
		
		
		
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		
		File file = new File("./snap/max.png");
		
		FileUtils.copyFile(screenshotAs, file);
		
//		Close the current window.
		
		driver.close();
		
//		Close the main window
		
		driver.switchTo().window(parentWindow);
		
		driver.close();
	}
	
}

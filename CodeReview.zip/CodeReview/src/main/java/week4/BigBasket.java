package week4;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class BigBasket {
	
	public static void main(String[] args) throws InterruptedException, IOException {
		
		// Navigate to https://www.bigbasket.com/.
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://www.bigbasket.com/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		// Click on "Shop by Category".
		
		driver.findElement(By.xpath("(//div[@class='relative h-full']/button)[2]")).click();
		
		// Mouse over "Foodgrains, Oil & Masala".
		
		Actions action = new Actions(driver);
		
		Thread.sleep(3000);
		
		WebElement chooseCategory = driver.findElement(By.xpath("(//a[text()='Foodgrains, Oil & Masala'])[2]"));
		
		action.moveToElement(chooseCategory).perform();
		
		// Mouse over "Rice & Rice Products".
		
		WebElement riceAndRice = driver.findElement(By.xpath("(//a[text()='Rice & Rice Products'])"));
		
		action.moveToElement(riceAndRice).perform();
		
		// Click on "Boiled & Steam Rice".
		
		driver.findElement(By.xpath("//a[text()='Boiled & Steam Rice']")).click();
		
		// Filter the results by selecting the brand "bb Royal".
		
		WebElement selectBrand = driver.findElement(By.id("i-BBRoyal"));
		
		driver.executeScript("arguments[0].click();", selectBrand);
		
		// Click on "Tamil Ponni Boiled Rice".
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//h3[contains(text(), 'Tamil Ponni Boiled')]")).click();
		
		// Select the 5 Kg bag.
		
		String parentWindow = driver.getWindowHandle();
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		List<String> newWindow = new ArrayList<String>(windowHandles);
		
		driver.switchTo().window(newWindow.get(1));
		
		Thread.sleep(3000);
		
		WebElement selectKg = driver.findElement(By.xpath("//span[text()='5 kg']"));
		
		action.scrollToElement(selectKg).click(selectKg).perform();
		
		// Check and note the price of the rice.
		
		String price = driver.findElement(By.xpath("//td[contains(text(), 'Price: ')]")).getText();
		
		System.out.println(price);
		
	//	Assert.assertEquals("Price: ₹350", price);
		
		// Click "Add" to add the bag to your cart.
		
		driver.findElement(By.xpath("(//button[text()='Add to basket'])")).click();
		
		// Verify the success message that confirms the item was added to your cart.
		
		Thread.sleep(2000);
		
		String verificationMessage = driver.findElement(By.xpath("//div[contains(@class, 'Toast___StyledDiv')]/p")).getText();
		
		System.out.println(verificationMessage);
		
		Assert.assertEquals("An item has been added to your basket successfully", verificationMessage);
		
		// Take Snapshot of the page
		
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		
		File des = new File("./snap/bigbasket.png");
		
		FileUtils.copyFile(screenshotAs, des);
		
		// close the current window
		
		driver.close();
		
		// close main window
		
		driver.switchTo().window(parentWindow);
		
		driver.close();
	}

}

package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class StepDefin {
	
	public ChromeDriver driver;
	
	
	@Given("I enter the URL {string}")
	public void launchBrowser(String url) {
		
		driver = new ChromeDriver();
		
		driver.get(url);

		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@When("I hover over {string} menu - xpath {string}")
	public void hoverover(String value ,String xpath) throws InterruptedException {
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.xpath(xpath));
		Actions act = new Actions(driver);
		act.moveToElement(element).perform();
	}
	@When("I click on the {string} menu - xpath {string}")
	public void click_on_brands(String values, String xpath ) throws InterruptedException {
		Thread.sleep(2000);
		WebElement click = driver.findElement(By.xpath(xpath));
		driver.executeScript("arguments[0].click();", click);
	}
	@When("User enters valid {string} xpath - {string}")
	public void first_name(String value , String xpath) {
		driver.findElement(By.xpath(xpath)).sendKeys(value);
		
	}
	@When("I click on the {string} continue - xpath {string}")
	public void clickonContinue(String values, String xpath ) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.id("continue")).click();
	}

}

package steps;

public class Student {
	
	String name = "Ragunath";
	
	public void student() {
		
		String name = "Ragunath";
	}

}

package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Facebook {
	
	public static void main(String[] args) {
		
		ChromeOptions op = new ChromeOptions();
		
		op.addArguments("--headless=new");
		
		
		ChromeDriver driver = new ChromeDriver(op);
		
		driver.manage().window().maximize();
		
		driver.get("https://www.facebook.com/");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.findElement(By.linkText("Create new account")).click();
		
		driver.findElement(By.name("firstname")).sendKeys("Ragunath");
		
		
	}

}

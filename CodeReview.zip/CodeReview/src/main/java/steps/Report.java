package steps;

public class Report {
	
	public static void main(String[] args) {
		
		Student obj = new Student();
		
		obj.student();
		
		System.out.println(obj.name);
	}

}

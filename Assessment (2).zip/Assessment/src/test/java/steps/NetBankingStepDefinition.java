package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NetBankingStepDefinition {
	
	public ChromeDriver driver;
	
	
	@Given("Launch the browser")
	public void launchBrowser() {
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--disable-notifications");
		driver = new ChromeDriver(option);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}
	
	@And("Load the Url")
	public void loadUrl() {

		driver.get("https://pizzaonline.dominos.co.in/menu");

	}
	
	@And("Click Veg Pizza")
	public void clickVegPizza() {
		
		driver.findElement(By.xpath("//span[text()='VEG PIZZA']")).click();

	}
	
	@And("Click Add to Cart for First Resulting Veg Pizza")
	public void clickAddtoCart() throws InterruptedException {
		
		driver.findElement(By.xpath("(//div[text()='VEG PIZZA']/following::button)[1]")).click();
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//button[@class='btn--trnpsnt-wht']")).click();

	}
	
	@And("Click Checkout button")
	public void clickCheckOutButton() {
		
		driver.findElement(By.xpath("//span[text()='CHECKOUT']")).click();
	}
	
	@When("Get Grand Total")
	public void getGrandTotal() {
		
		String text = driver.findElement(By.xpath("//div[@class='txt--wrpr marginTop']")).getText();
		
		System.out.println(text);

	}
	
	@Then("Click Place Order")
	public void clickPlacetoOrder() {
		
		driver.findElement(By.xpath("//button[@data-label='Place Order']")).click();
	}

}

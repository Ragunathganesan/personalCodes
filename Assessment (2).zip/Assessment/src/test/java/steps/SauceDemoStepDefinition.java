package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SauceDemoStepDefinition {

public ChromeDriver driver;
	
@Given("Launch The Browser")
	public void launchBrowser() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

@And("Load the URL")
	public void loadUrl() {
		
		driver.get("https://www.saucedemo.com/");

	}
	@And("Enter a Username as {string}")
	public void enterUsername(String userName) {
		
		driver.findElement(By.id("user-name")).sendKeys(userName);

	}
	@And("Enter a Password as {string}")
	public void enterPassword(String password) {
		
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	
	@And("Click Login Button")
	public void clickLoginButton() {
		
		driver.findElement(By.id("login-button")).click();
		
	}
	@And("Add Sauce Labs Onesie to the cart")
	public void clickAddCartForOnesie() {
		
		driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();
	}
	
	@And("Navigate to Shopping Cart")
	public void clickShoppingCart() {
		
		driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
		

	}
	
	@And("Click the Checkout Button")
	public void clickCheckout() {
	
		driver.findElement(By.id("checkout")).click();
		

	}
	@And("Enter the firstname")
	public void enterFirstname() {
		
		driver.findElement(By.id("first-name")).sendKeys("Ragunath");
	}
	
	@And("Enter the lastname")
	public void enterLastname() {
		
		driver.findElement(By.id("last-name")).sendKeys("Ganesan");

	}
	
	@And("Enter the Zip Code")
	public void enterZipCode() {
		
		driver.findElement(By.id("postal-code")).sendKeys("600125");

	}
	
	@When("Click Continue Button")
	public void clickContinue() {
		
		driver.findElement(By.id("continue")).click();

	}
	
	@Then("Read SauceCard number under Payment Information and print it in console")
	public void getSauceCardValue() {
		
		String sauceCard = driver.findElement(By.xpath("(//div[@class='summary_info']//div)[2]")).getText();
		
		System.out.println(sauceCard);
	}
}

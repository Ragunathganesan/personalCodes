package javaString;

public class ReverseString {
	
	public void reverseString() {
		
		String name = "Ragunath";
		
		char[] charArray = name.toCharArray();
		
		for (int i = charArray.length-1; i >=0 ; i--) {
			
			
			System.out.print(charArray[i]);
			
		}
	}
	
	
	public static void reverseName(String[] array) {
		
		
		for (int i = array.length-1; i >=0 ; i--) {
			
			System.out.print("\n" + array[i] + " ");
			
		}
	}
	
	public void reveseStringUsingStringBuilder() {
		
		String text = "Reverse String";
		
		StringBuilder builder = new StringBuilder(text);
		
		StringBuilder reverse = builder.reverse();
		
		System.out.println(reverse);

	}
	
	public static void main(String[] args) {
		
		ReverseString obj = new ReverseString();
		
//		obj.reverseString();
//		
//		String name = "Lavanya Sree Ragunath";
//		
//		String[] split = name.split(" ");
//		
//		
//		reverseName(split);
		
		obj.reveseStringUsingStringBuilder();
	}

}



package javaString;

import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterOccuranceUsingMap {
	
	public static void main(String[] args) {
		
		String name ="Ragunath Ganesan";
		
		char[] charArray = name.toCharArray();
		
		Map<Character, Integer> val = new LinkedHashMap<Character, Integer>();
		
		for (int i = 0; i < charArray.length; i++) {
			
			if (val.containsKey(charArray[i])) {
				
				Integer integer = val.get(charArray[i]);
				
				int newVal = integer+1;
				
				val.put(charArray[i], newVal);
				
			}
			
			else {
				
				val.put(charArray[i], 1);
			}
			
	}
		System.out.println(val);
	}

}

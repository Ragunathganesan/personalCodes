package javaString;

public class LearnMethodAndObject {

	 public void school1 ()
	 {
	System.out.println("St.Peter's");
	 }


	public int studentID (int Rollno , String studentname)
	{
		 System.out.println("Student Name: " + studentname);
	        System.out.println("Roll Number: " + Rollno);
	        // Return the roll number for simplicity
	        return Rollno;
	}
	public String studentName (String name)	
	{
		return name;
		
	}
	public String studentAddress (String Address)
	{
		return Address;
	}


	public static void main(String[] args)
	{


		LearnMethodAndObject m = new LearnMethodAndObject();
	m.school1();
	System.out.println(m.studentID(1, "Ragunath"));
	System.out.println(m.studentName("Abc"));
	//System.out.println("Student ID :" +m.studentID(1));
	System.out.println("Student Address :" +m.studentAddress("xyz"));
	//int stud1 = m.studentID(1, "abc");


	}
}

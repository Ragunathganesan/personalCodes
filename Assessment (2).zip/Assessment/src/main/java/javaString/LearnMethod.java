package javaString;

public class LearnMethod {
	
	// Method Syntax
	
	// accessModifier returnType methodname(){
	
	
	
	
//}
	
	// Access Modifier -- public, private, protected, default
	
	//returnType --> Primitive data types ( int , boolean ,char.....), Non Primitive data types (String), Void -->
	
	// methodName --> userDefine
	
	public void browserName() {
		
	System.out.println("Browser Version");
		
		
	}

	public void browserVersion() {
		
		System.out.println("Using Proctected");
	}
	
	
	public static void main(String[] args) {
		
	// Classname objName = new Classname();
		
		// objName ---> user define
		
		LearnMethod siva = new LearnMethod();
		
	siva.browserName();
	siva.browserVersion();
	
	}
	
	
}

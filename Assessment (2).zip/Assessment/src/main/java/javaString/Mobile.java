package javaString;

public class Mobile {
	
	
	
public static void main(String[] args) {
		
		// Classname objName = new Classname();
		
	LearnMethod ragu = new LearnMethod();
	
	ragu.browserName();
	ragu.browserVersion();
		
	}
	
	
}

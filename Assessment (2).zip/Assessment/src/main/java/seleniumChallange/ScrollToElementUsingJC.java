package seleniumChallange;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class ScrollToElementUsingJC {
	
	
	public static void main(String[] args) {
		
		ChromeOptions op = new ChromeOptions();
		
		op.addArguments("--disable-notifications");
		
		ChromeDriver driver = new ChromeDriver(op);
		
		driver.get("https://www.espncricinfo.com/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		// Using Action Class
		
		Actions action = new Actions(driver);
		
	//	WebElement keySeries = driver.findElement(By.xpath("//span[text()='Spotlight']"));
		
		WebElement keySeries = driver.findElement(By.xpath("//h2[text()='Key Series']"));
		
	//	action.scrollToElement(keySeries).perform();
		
		// Javascript
		
		driver.executeScript("arguments[0].scrollIntoView(true)", keySeries);
		
		
		
		
	}

}

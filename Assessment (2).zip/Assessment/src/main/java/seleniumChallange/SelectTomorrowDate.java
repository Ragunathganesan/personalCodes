package seleniumChallange;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectTomorrowDate {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("https://www.cheapoair.com/");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='modal-close-icon']")));

		try {
			driver.findElement(By.xpath("//div[@class='modal-close-icon']")).click();
		} catch (NoSuchElementException e) {

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='modal-close-icon']")));

			driver.findElement(By.xpath("//div[@class='modal-close-icon']")).click();
		}

		WebElement oneWay = driver.findElement(By.id("onewayTrip"));

		driver.executeScript("arguments[0].click();", oneWay);

		driver.findElement(By.xpath("(//a[contains(@class,'clear icon')])")).click();

		driver.findElement(By.xpath("//input[contains(@id, 'from')]")).sendKeys("MAA");

		driver.findElement(By.xpath("(//div[contains(@class, 'displayText')])")).click();

		driver.findElement(By.xpath("(//a[contains(@class,'clear icon')])[2]")).click();

		driver.findElement(By.xpath("//input[contains(@id, 'to')]")).sendKeys("DXB");

		driver.findElement(By.xpath("(//div[contains(@class, 'displayText')])")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("(//a[contains(@class, 'is--today')]/following::a)")).click();

		driver.findElement(By.id("travellerButton")).click();

		driver.findElement(By.id("addadults")).click();

		driver.findElement(By.id("addseniors")).click();

		driver.findElement(By.id("closeDialog")).click();

		driver.findElement(By.id("searchNow")).click();

		driver.findElement(By.xpath("//a[@class='close-icon']")).click();

		// visibilityOfAllElementsLocatedBy(By.xpath("//button[@title='SELECT']")));

	

		try {
			driver.findElement(By.xpath("//img[@alt='cross_icon']")).click();
		} catch (NoSuchElementException e) {

			Thread.sleep(2000);

			driver.findElement(By.xpath("//img[@alt='cross_icon']")).click();
		}

	Thread.sleep(2000);
		
		List<WebElement> allElements = driver.findElements(By.xpath("//span[@class='currency text-nowrap']//span[contains(@class, 'fpRoundToFixDecimal')]"));

		wait.until(ExpectedConditions.visibilityOfAllElements(allElements));
		
		Set<Double> prices = new TreeSet<>();
		for (WebElement eachEle : allElements) {
			String priceInString = eachEle.getText();
			double priceInDouble = Double.parseDouble(priceInString);
			prices.add(priceInDouble);
			
		}
		
		System.out.println(prices);

		// Collections.sort(allPrice); // Write a logic to find the least price
		List<Double> allPrice = new ArrayList<Double>(prices);
		Double least = allPrice.get(1);

		WebElement leastCode = driver
				.findElement(By.xpath("//span[@class='currency text-nowrap']//span[text()='"+least+"']//following::button"));

		driver.executeScript("arguments[0].click();", leastCode);

	}

}

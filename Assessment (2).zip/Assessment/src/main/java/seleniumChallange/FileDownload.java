package seleniumChallange;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.sukgu.Shadow;

public class FileDownload {
	
	public static void main(String[] args) throws InterruptedException {
		
		String downloadPath ="C:\\Users\\Admin\\Documents\\FileDownloadUA";
		
		ChromeOptions option = new ChromeOptions();
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		Map<String, Object> chromePref = new HashMap<String, Object>();
		
		chromePref.put("profile.default_content_settings.popups", 0);
		
		chromePref.put("download.default_directory", downloadPath);
		
		option.setExperimentalOption("prefs", chromePref);
		
		
		driver.get("https://ssc.gov.in/");
		
		Thread.sleep(3000);
		
		WebElement viewIcon = driver.findElement(By.xpath("(//span[@class='cp'])"));
		
		driver.executeScript("arguments[0].click();", viewIcon);
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		List<String> windows = new ArrayList<String>(windowHandles);
		
		driver.switchTo().window(windows.get(1));
		
		System.out.println(driver.getTitle());
		
		Thread.sleep(3000);
		
		Shadow dom = new Shadow(driver);
		
		dom.setImplicitWait(30);
		
		
		
		WebElement downloadIcon = dom.findElementByXPath("//*[@preserveAspectRatio='xMidYMid meet']");
		
		driver.executeScript("arguments[0].click();", downloadIcon);
		
	//	driver.findElement(By.id("icon")).click();
		
		
		
	}

}

package seleniumChallange;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MaruthiSuzuki {

	public static void main(String[] args) throws InterruptedException {
		
		// Open your preferred web browser.

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		// Go to Maruti Suzuki's official website “https://www.marutisuzuki.com/”

		driver.get("https://www.marutisuzuki.com/");
		
		// Click the search icon.

		driver.findElement(By.className("headerSearch-btn")).click();
		
		// Type “Swift” in the search field and press Enter.

		driver.findElement(By.name("key")).sendKeys("Swift", Keys.ENTER);
		
		// Click on the General Info icon for the Swift product.

		driver.findElement(By.className("icon-general_info")).click();
		
		// Select Car Variant at
		
		WebElement carVariant = driver.findElement(By.id("selectvariant1"));
		
		Select variant = new Select(carVariant);
		
		variant.selectByIndex(1);
		
		// Count the number of options in the city dropdown list.

		WebElement chooseCity = driver.findElement(By.id("selectcity1"));

		Select city = new Select(chooseCity);

		List<WebElement> options = city.getOptions();

		int size = options.size();

		System.out.println("Total Available Options: " + size);
		
		// Print the last option value in the city dropdown list and select it.

		String text = options.get(size - 1).getText();

		System.out.println(text);

		city.selectByVisibleText(text);
		
		// Click on the Safety section.

		driver.findElement(By.partialLinkText("SAFETY")).click();
		
		// Print the description under the Safety section.

		String safety = driver.findElement(By.className("caption-text")).getText();

		System.out.println("Safety Describtion : " + safety);
		
		// Click on the Colours section.

		driver.findElement(By.partialLinkText("COLOURS")).click();

		// Print the currently selected color.

		String carColoe = driver.findElement(By.tagName("small")).getAttribute("class");

		System.out.println("Car Color with attribute value " + carColoe);
		
		String[] split = carColoe.split("-");
		
		for (String string : split) {
			
			if (string.equals("red")||string.equals("black")) {
				
				System.out.println(string);
				
							
						
			}
			
		}
		driver.close();

	}

}
















































//String replaceAll = carColoe.replaceAll("(msr-|--pm-)", "");
//
//System.out.println("Selected car color is " + replaceAll);

// driver.get("https://www.instagram.com/accounts/login");

// driver.get("https://www.glassdoor.co.in/profile/login_input.htm");

// driver.get("https://www.dell.com/en-in");

// driver.get("https://www.lenovo.com/in/en/pc/");

//driver.findElement(By.linkText("Sign up")).click();
//
//driver.findElement(By.name("emailOrPhone")).sendKeys("9361884177");
//
//driver.findElement(By.name("fullName")).sendKeys("Rguanth_Ganesan");
//
//driver.findElement(By.name("username")).sendKeys("Ragunath");
//
//driver.findElement(By.name("password")).sendKeys("1234567890");
//
//driver.findElement(By.partialLinkText("Learn")).click();

//driver.findElement(By.id("inlineUserEmail")).sendKeys("ranjjith@gmail.com");
//
//driver.findElement(By.className("emailButton")).click();
//
//driver.findElement(By.id("inlineUserPassword")).sendKeys("1234567890");
//driver
//driver.findElement(By.xpath("showPasswordCheckbox")).click();

//driver.findElement(By.id("mh-search-input")).sendKeys("Dell Laptops", Keys.ENTER);
//
//driver.findElement(By.className("ps-compare-label")).click();
//
//driver.findElement(By.className("cf-view-dates")).click();
//
//driver.findElement(By.name("zipcode")).sendKeys("600125");
//
//driver.findElement(By.className("smrt-close-icon")).click();

// driver.findElement(By.id("commonHeaderSearch")).sendKeys("Accessories &
// Software");

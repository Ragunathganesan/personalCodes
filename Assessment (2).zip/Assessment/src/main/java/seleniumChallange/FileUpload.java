package seleniumChallange;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class FileUpload {

	public static void main(String[] args) throws AWTException, InterruptedException {

		// Open your preferred web browser.

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		// Go to the I Love pdf official website ‘https://www.ilovepdf.com/’

		driver.get("https://www.ilovepdf.com/");

		// Click the PDF to Word

		driver.findElement(By.xpath("//a[@title='PDF to Word']")).click();

		// Click the Select PDF

		driver.findElement(By.id("pickfiles")).click();

		// Upload your pdf file

		Thread.sleep(5000);

		StringSelection stringSelection = new StringSelection(
				"C:\\Users\\Admin\\Downloads\\Assessment\\data\\Locating Elements Using Basic Locators in Selenium with Java.pdf");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		// Paste it using Robot class
		Robot robot = new Robot();

		// Enter to confirm it is uploaded
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);

		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		Thread.sleep(3000);

		// driver.findElement(By.id("processTask")).click();

		// driver.findElement(By.id("pickfiles")).sendKeys(path+"\\data\\Locating
		// Elements Using Basic Locators in Selenium with Java.pdf");

	}

}

package seleniumChallange;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.sukgu.Shadow;

public class HandlingShadowRoot {

	public static void main(String[] args) {

		ChromeDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("https://shop.polymer-project.org");

		Actions action = new Actions(driver);

		Shadow dom = new Shadow(driver);

		WebElement scroll = dom.findElementByXPath("//div[text()='Demo Only']");

		action.scrollToElement(scroll).build().perform();

		dom.findElementByXPath("//h2[contains(text(), 'T-Shirts')]/following::a").click();

		dom.setImplicitWait(5);

		String totalItems = dom.findElementByXPath("//h1[contains(text(), 'T-Shirts')]/following-sibling::span")
				.getText();

		System.out.println(totalItems);

		List<WebElement> getAllPrices = dom.findElementsByXPath("//span[@class='price']");

		String firstProduct = getAllPrices.get(0).getText();

		for (int i = 0; i < getAllPrices.size(); i++) {

			String price = getAllPrices.get(i).getText();

			System.out.println(price);

		}

		List<WebElement> tshirtName = dom.findElementsByXPath("//div[@class='title']");

		for (int j = 0; j < tshirtName.size(); j++) {

			String tName = tshirtName.get(j).getText();

			System.out.println(tName);

		}

		dom.setImplicitWait(5);

		String firstTname = tshirtName.get(0).getText();

		dom.findElementByXPath("//div[text()='" + firstTname + "']").click();

		String price1 = dom.findElementByXPath("//div[@class='price']").getText();

		System.out.println(price1);

		if (firstProduct.equals(price1)) {

			System.out.println("Both Price Are Same");

		}

		else {

			System.out.println("Both Price Are Not Same");

		}

		WebElement selectSize = dom.findElementByXPath("//select[@id='sizeSelect']");

		Select size = new Select(selectSize);

		size.selectByVisibleText("XL");

		WebElement selectQuantity = dom.findElementByXPath("//select[@id='quantitySelect']");

		Select quantity = new Select(selectQuantity);

		quantity.selectByIndex(1);

		dom.findElementByXPath("//button[text()='Add to Cart']").click();

		dom.findElementByXPath("//a[@id='viewCartAnchor']").click();

		String subTotal = dom.findElementByXPath("//span[@class='subtotal']").getText();

		System.out.println(subTotal);

		driver.close();

	}

}

//dom.findElementByXPath("//input[@name='username']").sendKeys("Ragunath0595");
//
////dom.setImplicitWait(10);
//
//dom.findElementByXPath("//div[@class='form-group row']//following::input[@name='email']").sendKeys("raguntha@gmail.com");
//
//dom.findElementByXPath("//input[@name='password']").sendKeys("User@123");
//
//dom.findElementByXPath("//input[@name='confirm_password']").sendKeys("User@123");
//
//dom.findElementByXPath("//button[text()='Submit']").click();

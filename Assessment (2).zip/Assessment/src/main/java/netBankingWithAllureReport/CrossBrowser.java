package netBankingWithAllureReport;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowser {
public RemoteWebDriver driver;

@Parameters({"url","username","password"})

public void launchBrow(String url, String uname, String pwd) {
	
	driver.manage().window().maximize();
	driver.get(url);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	driver.findElement(By.id("username")).sendKeys(uname);
	driver.findElement(By.id("password")).sendKeys(pwd);
	driver.findElement(By.className("decorativeSubmit")).click();	

}

@Test(dataProvider="TestData")
public void CreateLead(String browser,String compname,String firstname ,String lastname)
{
if (browser.equalsIgnoreCase("Chrome")) {
	
	driver = new ChromeDriver();
	
}

else if(browser.equalsIgnoreCase("Edge")) {
	
	driver = new EdgeDriver();
}

else if(browser.equalsIgnoreCase("Firefox")) {
	
	driver = new FirefoxDriver();
}
 
	driver.manage().window().maximize();
	driver.get("http://leaftaps.com/opentaps/control/main");
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
	driver.findElement(By.id("password")).sendKeys("crmsfa");
	driver.findElement(By.className("decorativeSubmit")).click();
	driver.findElement(By.linkText("CRM/SFA")).click();
	driver.findElement(By.linkText("Leads")).click();
	driver.findElement(By.linkText("Create Lead")).click();
	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(compname);
	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
	driver.findElement(By.name("submitButton")).click();
	driver.close();
}

@DataProvider(name="TestData")
public String[][] sendData()

{
String[][] data=new String[][]
{{"Chrome","TestLeaf","Hari","R"},
{"Edge","TestLeaf","Hari","R"},
{"firefox","TestLeaf","Hari","R"}};
return data;
}
}
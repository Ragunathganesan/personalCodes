package doubtSession;

public class PrimeNumber {

	public static void main(String[] args) {
		
		int num = 6;
		
		int count =0;
		
		// div by 1
		// div by itself
		
		for (int i = 1; i <=num; i++) {
			
			if (num%i==0) {
				
				count++;
				
			}
			
		}
		
		if (count==2) {
			System.out.println("Given number is a prime number");
		}
		
		else {
			
			System.out.println("Not prime number");
		}
	}

}

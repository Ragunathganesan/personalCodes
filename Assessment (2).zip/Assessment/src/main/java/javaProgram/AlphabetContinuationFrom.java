package javaProgram;

import java.util.Scanner;

public class AlphabetContinuationFrom {
	
	
	public static void alphabetContinuationFrom() {

//		String name = "Ragunath";
//		
//		char[] charArray = name.toCharArray();
//		
//		char startChar = charArray[1];
		
		Scanner scan = new Scanner(System.in);
		
		String trim = scan.nextLine().trim();
		
		char startChar = 'A';
		
		System.out.println("Continuation of alphabet from 'A': ");
		
		for (char i = startChar ; i <='Z'; i++) {
			
			System.out.println(i);
			
		}
		
		System.out.println();

	}
	
	public static void withOutScanner() {
		
		String name = "Ragunath";
		
		char charAt = name.charAt(0);
		
		 if (name.indexOf(charAt) == -1) {
	            System.out.println("The chosen character is not in the string.");
	           return;
	        }
		
		 System.out.print("Alphabetic characters after '" + charAt + "': ");
	        for (char c = (char) (charAt + 1); c <= 'z' || c<='Z'; c++) {
	            System.out.print(c + " ");
	        }
//	//	String name = "";
//		
//		// String trim = name.trim();
//		 
//		 char startWith = 'R';
//		 
//		 for (char i = startWith; i < 'Z'; i++) {
//			 
//			 System.out.println(i);
//			
	//	}
		
		// System.out.println();

	}
	
	
	
	public static void main(String[] args) {
		
		//alphabetContinuationFrom();
		withOutScanner();
	}

}

package javaProgram;

import java.util.Arrays;
import java.util.Collections;

public class SortOrder {
	
	public static void main(String[] args) {
		
//		Integer[] num = {0,1,0,1,0,1};
//		
//		Arrays.sort(num, Collections.reverseOrder());
//		
//		for (int i = 0; i < num.length; i++) {
//			
//			System.out.println(num[i]);
//			
//		}
		
		String s ="testleaf";
		
		int count = 0;
		
		char  c ='l';
		
		for (int i = 0; i < s.length(); i++) {
			
			if (c==s.charAt(i)) {
				
				count++;
				
			}
			
		}
		
		System.out.println(count);
	}

}

package javaProgram;

public class ParttenPrint {
	
	public static void main(String[] args) {
		
		for (int i = 0; i <=20; i++) {
			
			for (int j = 1; j <=i; j++) {
				
				
				System.out.print("*");
				
			}
			
			System.out.println();
			
		}
	}

}

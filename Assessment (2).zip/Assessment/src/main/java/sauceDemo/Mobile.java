package sauceDemo;

import javaString.LearnMethod;

public class Mobile {

public static void main(String[] args) {
		
		// Classname objName = new Classname();
		
	LearnMethod ragu1 = new LearnMethod();
	
	ragu1.browserName();
	ragu1.browserVersion();
	
		
	}
}

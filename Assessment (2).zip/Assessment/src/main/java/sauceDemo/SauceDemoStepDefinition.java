package sauceDemo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class SauceDemoStepDefinition {
	
	public ChromeDriver driver;
	
	public void launchBrowser() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	public void loadUrl() {
		
		driver.get("https://www.saucedemo.com/");

	}
	
	public void enterUsername(String userName) {
		
		driver.findElement(By.id("user-name")).sendKeys(userName);

	}
	
	public void enterPassword(String password) {
		
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	public void clickLoginButton() {
		
		driver.findElement(By.id("login-button")).click();
		
	}
	
	public void clickAddCartForOnesie() {
		
		driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();
	}
	
	public void clickShoppingCart() {
		
		driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
		

	}
	
	public void clickCheckout() {
	
		driver.findElement(By.id("checkout")).click();
		

	}
	
	public void enterFirstname() {
		
		driver.findElement(By.id("first-name")).sendKeys("Ragunath");
	}
	
	public void enterLastname() {
		
		driver.findElement(By.id("last-name")).sendKeys("Ganesan");

	}
	
	public void enterZipCode() {
		
		driver.findElement(By.id("postal-code")).sendKeys("600125");

	}
	
	public void clickContinue() {
		
		driver.findElement(By.id("continue")).click();

	}
	
	public void getSauceCardValue() {
		
		String sauceCard = driver.findElement(By.xpath("(//div[@class='summary_info']//div)[2]")).getText();
		
		System.out.println(sauceCard);
	}
}

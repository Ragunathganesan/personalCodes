package hooks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.Base;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.qameta.allure.Allure;

public class HooksImplementation extends Base{

	@Before
	public void preConditiom() {
		driver=new ChromeDriver();
		driver.get("https://commercejs-demo-store.netlify.app/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));        

	}

	@After
	public void postCondition() {
       driver.quit();

	}

	@AfterStep
	public void takeSnap() throws FileNotFoundException {
		File src = driver.getScreenshotAs(OutputType.FILE);
		Allure.addAttachment("Snapshot", new FileInputStream(src));

	}

}

package runner;

import base.Base;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/features_commerceStore/Purchase_Product.feature", 
glue = {"steps_CommerceStore","hooks"},
plugin= {"io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"},
monochrome = true, publish = true)

public class CucumberRunner extends Base {

}

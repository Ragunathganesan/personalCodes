package tasks;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public class CreateTasks {

	public static void main(String[] args) throws InterruptedException {

		ChromeOptions option = new ChromeOptions();

		option.addArguments("--disable-notifications");

		ChromeDriver driver = new ChromeDriver(option);

		driver.get("https://login.salesforce.com/?locale=in");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.findElement(By.id("username")).sendKeys("ragunath.testleaf@gmail.com");

		driver.findElement(By.id("password")).sendKeys("Testleaf123");

		driver.findElement(By.id("Login")).click();

		driver.findElement(By.xpath("//button[contains(@class,'salesforceIdentityAppLauncherHeader')]")).click();

		driver.findElement(By.xpath("//button[text()='View All']")).click();

		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Tasks");

		driver.findElement(By.xpath("//mark[text()='Tasks']")).click();

		driver.findElement(By.xpath("//a[contains(@class, 'slds-button--icon-border-filled')]")).click();

		driver.findElement(By.xpath("//a[@title='New Task']")).click();

		Thread.sleep(5000);

		driver.findElement(By.xpath("(//label[@class='slds-form-element__label']/following::input)[1]")).click();

		WebElement subject = driver
				.findElement(By.xpath("(//div[contains(@id, 'dropdown-element')]//following::span)[2]"));

		String subEle = subject.getAttribute("title");

		Thread.sleep(3000);

		driver.findElement(By.xpath("(//div[contains(@id, 'dropdown-element')]//following::span)[1]")).click();

		driver.findElement(By.xpath("(//span[contains(@class, 'uiPicklistLabel')]//following::div)")).click();

		driver.findElement(By.xpath("//a[@title='In Progress']")).click();

		driver.findElement(By.xpath("(//button[contains(@class, 'forceActionButton')])[3]")).click();

		String taskCreate = driver.findElement(By.xpath("//span[contains(@class, 'forceActionsText')]")).getText();

		System.out.println(taskCreate);

		Assert.assertEquals(taskCreate, taskCreate);
		
		Thread.sleep(7000);
		
		WebElement sideDropDown = driver.findElement(By.xpath("//a[contains(@class, 'sldsButtonHeightFix')]"));

		driver.executeScript("arguments[0].click();", sideDropDown);

		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		
		WebElement status = driver.findElement(By.xpath("(//span[text()='Status'])[2]//following::div"));

		driver.executeScript("arguments[0].click();",status);
		
		driver.findElement(By.xpath("//a[@title='Waiting on someone else']")).click();

		driver.findElement(By.xpath("//div[contains(@class, 'slds-input-has-icon_right')]/input")).click();

		driver.findElement(By.xpath("//td[@class='slds-is-today']/following::td[1]")).click();

		driver.findElement(By.xpath("(//span[contains(@class, 'label uiPicklistLabel')])[2]//following::div[1]"))
				.click();

		driver.findElement(By.xpath("//a[@title='Low']")).click();
		
		//Thread.sleep(3000);

		driver.findElement(By.tagName("textarea")).sendKeys("Task created and edited successfuly");

		driver.findElement(By.xpath("//button[@title='Save']")).click();

		String taskEdit = driver.findElement(By.xpath("//span[contains(@class, 'forceActionsText')]")).getText();

		System.out.println(taskEdit);

		Assert.assertEquals(taskEdit, taskEdit);

	}

}

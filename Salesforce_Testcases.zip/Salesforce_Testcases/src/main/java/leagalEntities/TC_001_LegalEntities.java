package leagalEntities;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;


public class TC_001_LegalEntities {
	
	@Test
	
	public  void legalEntities() throws InterruptedException {
		
		//WebDriverManager.chromedriver().setup();
		
		ChromeOptions option = new ChromeOptions();
		
		option.addArguments("--disable-notifications");
		
		option.setBinary("C:\\Users\\Admin\\Downloads\\Chrome 115\\chrome-win64\\chrome.exe");
		
		ChromeDriver driver = new ChromeDriver(option);
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://login.salesforce.com/?locale=in");
		
		driver.findElement(By.id("username")).sendKeys("ragunath.testleaf@gmail.com");
		
		driver.findElement(By.id("password")).sendKeys("Ganesan@1727");
		
		driver.findElement(By.id("Login")).click();
		
		driver.findElement(By.xpath("//button[contains(@class,'salesforceIdentityAppLauncherHeader')]")).click();
		
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Legal Entities");
		
		driver.findElement(By.xpath("//mark[text()='Legal Entities']")).click();
		
		driver.findElement(By.xpath("//div[text()='New']")).click();
		
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("Salesforce");
		
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		
		Thread.sleep(3000);
		
		String legalEntitiesName = driver.findElement(By.xpath("//span[contains(@class, 'forceActionsText')]")).getText();
		
		
		if (legalEntitiesName.contains("was created")) {
			
			
			System.out.println("Legal Entities was created Successfully");
			
		}
		else {
			
			System.out.println("Legal Entities Not Created");
		}
		
		driver.close();
	}

}

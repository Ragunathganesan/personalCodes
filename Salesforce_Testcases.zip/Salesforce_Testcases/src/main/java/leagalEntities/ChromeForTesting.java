package leagalEntities;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromeForTesting {

	public static void main(String[] args) {
		
		ChromeOptions option = new ChromeOptions();
		
		
		
		option.setBinary("118").setBrowserVersion("118");
		
		ChromeDriver driver = new ChromeDriver(option);
		
		driver.get("http://leaftaps.com/opentaps/control/main");
	}
}

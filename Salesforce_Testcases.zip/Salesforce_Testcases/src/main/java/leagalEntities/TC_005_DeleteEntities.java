package leagalEntities;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_005_DeleteEntities {

	@Test
	public void deleteEntities() throws InterruptedException {
		
//WebDriverManager.chromedriver().setup();
		
		ChromeOptions option = new ChromeOptions();
		
		option.addArguments("--disable-notifications");
		
		option.setBinary("C:\\Users\\Admin\\Downloads\\Chrome 115\\chrome-win64\\chrome.exe");
		
		ChromeDriver driver = new ChromeDriver(option);
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://login.salesforce.com/?locale=in");
		
		driver.findElement(By.id("username")).sendKeys("ragunath.testleaf@gmail.com");
		
		driver.findElement(By.id("password")).sendKeys("Ganesan@1727");
		
		driver.findElement(By.id("Login")).click();
		
		driver.findElement(By.xpath("//button[contains(@class,'salesforceIdentityAppLauncherHeader')]")).click();
		
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Legal Entities");
		
		driver.findElement(By.xpath("//mark[text()='Legal Entities']")).click();
		
		driver.findElement(By.xpath("//input[@name='LegalEntity-search-input']")).sendKeys("Salesforce", Keys.ENTER);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//a[contains(@class, 'rowActionsPlaceHolder')])[1]")).click();
		
		driver.findElement(By.xpath("//a[@title='Delete']")).click();
		
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		
		String deleteEntities = driver.findElement(By.xpath("//span[contains(@class, 'forceActionsText')]")).getText();
		
		System.out.println("Deleted Entities is "+deleteEntities);
		
		driver.close();
	}
}

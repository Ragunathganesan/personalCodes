package leagalEntities;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_002_EditLeagalEntities {
	@Test
	public void editLeagalEntities() throws InterruptedException {
		
	//WebDriverManager.chromedriver().setup();
		
		ChromeOptions option = new ChromeOptions();
		
		option.addArguments("--disable-notifications");
		
		option.setBinary("C:\\Users\\Admin\\Downloads\\Chrome 115\\chrome-win64\\chrome.exe");
		
		ChromeDriver driver = new ChromeDriver(option);
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.get("https://login.salesforce.com/?locale=in");
		
		driver.findElement(By.id("username")).sendKeys("ragunath.testleaf@gmail.com");
		
		driver.findElement(By.id("password")).sendKeys("Ganesan@1727");
		
		driver.findElement(By.id("Login")).click();
		
		driver.findElement(By.xpath("//button[contains(@class,'salesforceIdentityAppLauncherHeader')]")).click();
		
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Legal Entities");
		
		driver.findElement(By.xpath("//mark[text()='Legal Entities']")).click();
		
		driver.findElement(By.xpath("//input[@name='LegalEntity-search-input']")).sendKeys("Salesforce", Keys.ENTER);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//a[contains(@class, 'rowActionsPlaceHolder')])[1]")).click();
		
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		
		driver.findElement(By.xpath("//input[@name='CompanyName']")).sendKeys("Testleaf");
		
		driver.findElement(By.xpath("(//div[@class='slds-form-element__control slds-grow textarea-container']//textarea)[2]")).sendKeys("Salesforces");
		
		WebElement statusD = driver.findElement(By.xpath("//button[@aria-label='Status, --None--']"));
		
		driver.executeScript("arguments[0].click();", statusD);
		
		driver.findElement(By.xpath("//span[text()='Active']")).click();
		
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		
		WebElement name = driver.findElement(By.xpath("//input[@name='LegalEntity-search-input']"));
		
		name.clear();
		
		name.sendKeys("Salesforce", Keys.ENTER);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//a[contains(@class, 'forceOutputLookup')])[1]")).click();
		
		Thread.sleep(3000);
		
		String status = driver.findElement(By.xpath("(//p[contains(@class, 'fieldComponent')])[2]")).getText();
		
		if (status.contains("Active")) {

			System.out.println("Legal Entities Edited Successfully");
		}
		
		else {
			
			System.out.println("Not Edit");
		}
		
		driver.close();
	}

}

package registerNewCustomer;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

public class TC_001_RegisterNewCustomer {

	public static void main(String[] args) {
		
		ChromeDriver driver = new ChromeDriver();
		driver.get("");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		
	}

}
